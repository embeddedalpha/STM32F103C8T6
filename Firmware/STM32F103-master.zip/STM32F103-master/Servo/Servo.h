#ifndef _SERVO_H_
#define _SERVO_H_


#include "stm32f10x.h"


void Servo_1_Init(void);
void Servo_1_Update(float angle);

void Servo_2_Init(void);
void Servo_2_Update(float angle);
	
void Servo_3_Init(void);
void Servo_3_Update(float angle);

void Servo_4_Init(void);
void Servo_4_Update(float angle);
	
void Servo_5_Init(void);
void Servo_5_Update(float angle);
	
void Servo_6_Init(void);
void Servo_6_Update(float angle);
	
void Servo_7_Init(void);
void Servo_7_Update(float angle);

void Servo_8_Init(void);
void Servo_8_Update(float angle);
	
void Servo_9_Init(void);
void Servo_9_Update(float angle);

void Servo_10_Init(void);
void Servo_10_Update(float angle);
	
void Servo_11_Init(void);
void Servo_11_Update(float angle);
	
void Servo_12_Init(void);
void Servo_12_Update(float angle);
	
void Servo_13_Init(void);
void Servo_13_Update(float angle);

void Servo_14_Init(void);
void Servo_14_Update(float angle);
	
void Servo_15_Init(void);
void Servo_15_Update(float angle);

void Servo_16_Init(void);
void Servo_16_Update(float angle);
	













#endif


