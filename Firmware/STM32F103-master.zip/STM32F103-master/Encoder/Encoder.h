#ifndef _ENCODER_H_
#define _ENCODER_H_


#include "stm32f10x.h"



void Encoder_Int();
int read_encoder();







#endif