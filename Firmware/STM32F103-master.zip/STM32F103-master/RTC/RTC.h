#ifndef _RTC_H_
#define _RTC_H_

#include "stm32f10x.h"



void RTC_Init();











#endif 