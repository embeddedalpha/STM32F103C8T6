#ifndef _W5500_TCP_
#define _W5500_TCP_

#include "W5500.h"

/*
Basic settings
mode register = 
*/






#endif
