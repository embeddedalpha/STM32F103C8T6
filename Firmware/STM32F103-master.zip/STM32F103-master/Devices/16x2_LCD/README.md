<h1> 16 x 2 LCD </h1> 

![16x2-LCD-Pinout](https://user-images.githubusercontent.com/38166489/72966592-5751b880-3de5-11ea-9bff-3e84faa999f3.png)
