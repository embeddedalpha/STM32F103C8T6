<h1> Libraries and Example Code for Various Devices </h1> 
<h3> 1. SSD1306 OLED Display</h3>
<h3> 2. 16x2 LCD Display </h3>
<h3> 3. HC-SR04 Ultrasonic Sensor </h3>
<h3> 4. RC522 RFID </h3>
<h3> 5. MCP2515 CAN Controller </h3>
<h3> 6. W5500 Ethernet Controller </h3>
<h3> 7. HC05 Bluetooth Module </h3>
