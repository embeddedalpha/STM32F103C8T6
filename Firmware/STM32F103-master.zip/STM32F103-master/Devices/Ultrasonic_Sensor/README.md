<h1> Ultrasonic Sensor </h1>
<h3> HC-SR004 </h3>

![hcsr04](https://user-images.githubusercontent.com/38166489/72965612-d4c7f980-3de2-11ea-8754-c6c52a8a1447.PNG)

<h3> Timing Diagram </h3>

![hcsr04_timing](https://user-images.githubusercontent.com/38166489/72965982-b57d9c00-3de3-11ea-8f7d-6de53884222e.PNG)


