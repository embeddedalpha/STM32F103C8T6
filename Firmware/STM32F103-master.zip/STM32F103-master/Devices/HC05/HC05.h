#ifndef _HC05_H_
#define _HC05_H_

#include "stm32f10x.h"
#include "Console.h"


int BL_HC05_Init(void);
int wait_till_ok(void);










#endif
